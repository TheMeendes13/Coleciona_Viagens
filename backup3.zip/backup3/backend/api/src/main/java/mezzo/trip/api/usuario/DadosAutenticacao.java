package mezzo.trip.api.usuario;

public record DadosAutenticacao(String email, String senha) {
}
