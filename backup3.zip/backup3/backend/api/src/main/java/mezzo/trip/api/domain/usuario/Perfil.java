package mezzo.trip.api.domain.usuario;

public enum Perfil {

    Urbano,
    Refinado,
    Natureba,
    Relax,
    Aventureiro,
    Cultural,
    Intercambista,
    Romântico,
    Mochileiro,
    Guia

}
