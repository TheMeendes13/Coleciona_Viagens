package mezzo.trip.api.domain.usuario;

public enum Genero {

    HOMEM_CIS,
    MULHER_CIS,
    HOMEM_TRANS,
    MULHER_TRANS,
    NAO_BINARIO


}
