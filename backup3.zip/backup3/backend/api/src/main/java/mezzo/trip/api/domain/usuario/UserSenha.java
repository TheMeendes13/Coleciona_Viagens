package mezzo.trip.api.domain.usuario;

public class UserSenha {

    private Long id;
    private String login;
    private String senha;
}
