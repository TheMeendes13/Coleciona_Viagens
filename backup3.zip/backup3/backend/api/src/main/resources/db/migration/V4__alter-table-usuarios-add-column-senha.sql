alter table usuarios add senha varchar(100);
update usuarios set senha = 1234;