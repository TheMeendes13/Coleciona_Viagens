//
//  Coleciona_ViagensApp.swift
//  Coleciona Viagens
//
//  Created by Wesley Mendes on 13/06/24.
//

import SwiftUI

@main
struct Coleciona_ViagensApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
